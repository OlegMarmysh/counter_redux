import React from 'react';
import styles from './App.module.css';
import Display from "./Display";
import Buttons from "./Buttons";

class App extends React.Component {

    state = {
        startValue: 0,
        maxValue: 3,
        currentValue: 0,
        isShowHide: 'true'
    }

    onPlusValue = () => {
        if (this.state.currentValue < this.state.maxValue) {
            this.setState(
                {currentValue: this.state.currentValue + 1},
                ()=>{this.saveState()}
            )
        }
    }
    onReset = () => {
        this.setState(
            {currentValue: this.state.startValue},
            ()=>{this.saveState()}
        )
    }
    onShowSettings = () => {
        this.setState(
            {
                isShowHide: false,
            },
            ()=>{this.saveState()}
        )
    }
    onHideSettings = () => {
        this.setState(
            {
                isShowHide: true,
                currentValue: this.state.startValue,
                maxValue: this.state.maxValue
            },
            ()=>{this.saveState()}
        )
    }
    onMaxValueChange = (number) => {
        this.setState(
            {maxValue: number},
            ()=>{this.saveState()}
        )
    }
    onStartValueChange = (number) => {
        this.setState(
            {startValue: number},
            ()=>{this.saveState()}
        )
    }
    componentDidMount() {
        this.restoreState()
    }

    restoreState = () => {
        let state = {startValue: 0,
            maxValue: 3,
            currentValue: 0,
            isShowHide: 'true'
        }
        let stateAsString=localStorage.getItem('our-state')
        if(stateAsString != null){
            state = JSON.parse(stateAsString)
        }
        this.setState(state)
    }
    saveState = () => {
        let stateAsString = JSON.stringify(this.state)
        localStorage.setItem('our-state',stateAsString)
    }
    render = () => {
        return (
            <div className={styles.app}>
                <Display state={this.state}
                         isShowHide={this.state.isShowHide}
                         onShowSettings={this.onShowSettings}
                         onMaxValueChange={this.onMaxValueChange}
                         onStartValueChange={this.onStartValueChange}
                />
                <Buttons onPlusValue={this.onPlusValue}
                         state={this.state}
                         isShowHide={this.state.isShowHide}
                         onReset={this.onReset}
                         onShowSettings={this.onShowSettings}
                         onHideSettings={this.onHideSettings}
                />
            </div>
        )
    }
}


export default App;
